/*
*(C) Copyright 2021 Fresher Academy. All Rights Reserved.
*
* @author: Phạm Hoàng Anh
* @date: Dec 8, 2023
*/

package fa.training.assignment1;

public class ArithmeticExercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 double result = ((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
	     System.out.println(result);
	}

}
