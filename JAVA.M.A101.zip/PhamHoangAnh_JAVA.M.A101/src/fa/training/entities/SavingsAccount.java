/*
*(C) Copyright 2021 Fresher Academy. All Rights Reserved.
*
* @author: Phạm Hoàng Anh
* @date: Dec 8, 2023
*/

package fa.training.entities;

public class SavingsAccount {
		
		// Instance variables 
		private static double annualInterestRate;
	    private double savingsBalance;

	    // Constructror
	    public SavingsAccount() {
	        this.savingsBalance = 0;
	        this.annualInterestRate = 0;
	    }
	    
	    // Instance methods
	    public double getSavingsBalance() {
	        return savingsBalance;
	    }
	    
	    public void setSavingBalance(double savingsBalance) {
	    	this.savingsBalance = savingsBalance;
	    }
	    
	    public SavingsAccount(double annualInterestRate, double savingsBalance) {
	        this.annualInterestRate = annualInterestRate;
	        this.savingsBalance = savingsBalance;
	    }
	    
	    public static double getAnnualInterestRate() {
	        return annualInterestRate;
	    }

	    public static void setAnnualInterestRate(double annualInterestRate) {
	    	SavingsAccount.annualInterestRate = annualInterestRate;
	    }
	    
	    public void calculateMonthlyInterest() {
	        savingsBalance += savingsBalance * annualInterestRate / 12;
	    }
	
}