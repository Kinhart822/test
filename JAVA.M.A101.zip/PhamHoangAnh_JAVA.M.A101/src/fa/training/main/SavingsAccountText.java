/*
*(C) Copyright 2021 Fresher Academy. All Rights Reserved.
*
* @author: Phạm Hoàng Anh
* @date: Dec 8, 2023
*/

package fa.training.main;

import fa.training.entities.SavingsAccount;

public class SavingsAccountText {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SavingsAccount saver1 = new SavingsAccount(0, 2000);
        SavingsAccount saver2 = new SavingsAccount(0, 3000);
        SavingsAccount.setAnnualInterestRate(0.04);
        
        for (int i = 0; i < 12; i++) {
            saver1.calculateMonthlyInterest();
            saver2.calculateMonthlyInterest();
        }
        
        // Set the annualInterestRate to 4%
        System.out.println("The annualInterestRate = 4%");
        System.out.println("Saver1: $" + saver1.getSavingsBalance());
        System.out.println("Saver2: $" + saver2.getSavingsBalance());
        		
        // Set the annualInterestRate to 5%
        SavingsAccount.setAnnualInterestRate(0.05);
        saver1.calculateMonthlyInterest();
        saver2.calculateMonthlyInterest();
        
        System.out.println("The annualInterestRate = 5%");
        System.out.println("Saver1: $" + saver1.getSavingsBalance());
        System.out.println("Saver2: $" + saver2.getSavingsBalance());
	}

}
