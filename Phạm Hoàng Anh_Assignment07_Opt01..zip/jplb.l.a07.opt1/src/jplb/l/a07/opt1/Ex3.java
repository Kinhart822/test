/*
*(C) Copyright 2021 Fresher Academy. All Rights Reserved.
*
* @author: Phạm Hoàng Anh
* @date: Dec 8, 2023
*/

package jplb.l.a07.opt1;

public class Ex3 {

	public static void main(String[] args) {
		String str1 = " \"Fresher Academy\" ";
		
		String str2 = " \"FRESHER ACADEMY\" ";
		
		String str3 = " \"fReSher aCadeMy\" ";
	
		System.out.println(str1.toUpperCase()); 
		System.out.println(str2.toUpperCase()); 
		System.out.println(str3.toUpperCase()); 



	}

}
