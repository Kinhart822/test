/*
*(C) Copyright 2021 Fresher Academy. All Rights Reserved.
*
* @author: Phạm Hoàng Anh
* @date: Dec 8, 2023
*/

package jplb.l.a07.opt1;

public class Ex2 {

	public static void main(String[] args) {
	    
		String str1 = "FRESHER ACADEMY";
	    System.out.println(str1);
	    System.out.print("The length of \"" + str1 + "\" is: " + str1.length());
	}

}
