/*
*(C) Copyright 2021 Fresher Academy. All Rights Reserved.
*
* @author: Phạm Hoàng Anh
* @date: Dec 8, 2023
*/

package jplb.l.a03.opt1;

public class Exercise05 {

	public static void main(String[] args) {
		welcome("John");
	    welcome("David");
	}
	
	static void welcome(String name) {
	    System.out.println("Hello " + name);
	}

}
